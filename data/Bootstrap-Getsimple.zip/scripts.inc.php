<?php if(!defined('IN_GS')){ die('you cannot load this page directly.'); }
/****************************************************
*
* @File:      scripts.inc.php
* @Package:   GetSimple
* @Action:    Bootstrap Theme for GetSimple CMS
*
*****************************************************/
?>
<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>